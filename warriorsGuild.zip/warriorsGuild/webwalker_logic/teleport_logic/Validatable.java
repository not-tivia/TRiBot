package scripts.warriorsGuild.webwalker_logic.teleport_logic;


public interface Validatable {
    boolean canUse();
}
